# Orbit UI

Тёмная React-библиотека на основе Orbit D5. В пакете лежат компоненты, CSS с токенами, шрифт Golos Text и декларации TypeScript. Для React и React DOM нужны версии 18.2 или 19. Пакет экспортирует ES-модуль.

## Подключение

```sh
npm install ./kiridey-orbit-ui-0.2.0.tgz
```

```tsx
import {useState} from 'react';
import {Button, OrbitProvider, Stack, TabBar, TabPanel} from '@kiridey/orbit-ui';
import '@kiridey/orbit-ui/styles.css';

const items = [
  {value: 'files', label: 'Файлы', icon: <span>▤</span>},
  {value: 'settings', label: 'Настройки', icon: <span>⚙</span>},
];

export function App() {
  const [section, setSection] = useState('files');
  return (
    <OrbitProvider>
      <Stack>
        <TabBar id="workspace" label="Разделы" items={items}
          value={section} onValueChange={setSection} />
        {items.map(item => (
          <div key={item.value} hidden={section !== item.value}>
            <TabPanel id="workspace" value={item.value}>
              {item.value === 'files' ? <Button>Новая папка</Button> : item.label}
            </TabPanel>
          </div>
        ))}
      </Stack>
    </OrbitProvider>
  );
}
```

Пара `id` и `value` связывает пункт и панель для вспомогательных технологий. Для навигации по URL передавай `href` у пунктов, а активный `value` бери из роутера. Выбранное значение, данные, асинхронные операции и обработчики принадлежат приложению.

## Компоненты по листам D5

| Лист | Реализация |
| --- | --- |
| Компоненты | `OrbitProvider`, `Container`, `Stack`, `Button`, `Switch`, `Checkbox`, `RadioGroup`, `FilterChips`, `Segmented`, `TextField`, `SearchField`, `Progress`, `ListStatus`, `Banner`, `Toast`, `ActionBar` |
| Формы и выбор | `SelectField`, `Combobox`, `MultiSelect`, `TextArea`, `InsetForm` и его строки, `Calendar`, `DateField`, `TimeField`, `NumberInput`, `PasswordField`, `OTP`, `FileDropzone`, `UploadItem`, `FormActions`, `Slider`, `Scrubber` |
| Навигация и состояния | `SideNav`, `Breadcrumbs`, `Pagination`, `Stepper`, `Dialog` и его вариант `sheet`, `Popover`, `Tooltip`, `SkeletonList`, `EmptyState`, `ErrorState`, `List` и его три варианта |
| Цветовые темы | `resolveOrbitTheme` для профиля с HEX-цветом, `createOrbitTheme` для прямого задания тона и цветности |
| Мобильное стекло | `AdaptiveNavigation`, `MobileTabBar`, `Header`, `SelectionBar`, `SelectionToolbar`, стеклянные и сплошные поверхности |
| Правила компонентов | `TabBar`, `TabPanel`, `PageHeader`, `Menu`, `MenuPanel`, `MenuSub`, `MenuQuickActions`, `ContextMenu` с отдельным превью, `ListItem` со свайпом и `useSelectionShortcuts` |

## Поведение

- **Навигация.** Касание выбирает пункт. При горизонтальном движении капсула следует за пальцем или мышью, а раздел меняется при отпускании над доступным пунктом. Вертикальная прокрутка, отмена жеста и уход за пределы панели возвращают капсулу. Стрелки и Home/End перемещают фокус, Enter или Space активирует пункт. Если вкладки перестают помещаться при увеличенном тексте, появляется нативный выбор раздела. У `MobileTabBar` есть раскрываемый поиск для iOS-компоновки и опциональное сворачивание при прокрутке. `AdaptiveNavigation` размещает Web/Android вниз на ширине до 599 px и вверх с 600 px. С 880 px встают боковые слоты. На узких или низких экранах подпись остаётся у активной вкладки.
- **Меню.** Вложенная панель заменяет родительскую на месте. Back или Escape возвращает к пункту, из которого она была открыта. Проверяемые настройки оставляют панель открытой. У `ContextMenu` рабочие правый клик и удержание. Передай `previewPlacement="separate"` для карточки вне поверхности меню. Для действий, важных на всех платформах, оставляй видимую кнопку меню.
- **Строки.** Горизонтальный свайп открывает до двух быстрых команд. В списке одновременно раскрывается одна строка. С клавиатуры Alt+↓ на строке открывает команды, Escape закрывает и возвращает фокус. Если есть режим выбора, передавай `onSelectedChange`. Он включает чекбокс и освобождает жесты строки. Для массового выбора передавай счётчики текущей страницы и всей выдачи раздельно.
- **Ввод и диалоги.** OTP использует одно поле с `autocomplete="one-time-code"` и поддерживает вставку кода. В календаре стрелки переключают дни. В подтверждениях с удалением помечай кнопку отмены атрибутом `data-orbit-autofocus`. У `Dialog` можно передать `restoreFocus`, если триггер находится за пределами диалога.
- **Поиск по вариантам и загрузка.** `Combobox` и `MultiSelect` принимают массив опций и выбранные значения. Стрелки перемещают фокус по доступным вариантам, Enter выбирает, Escape закрывает список. Backspace в пустом поле мультивыбора убирает последний тег. `FileDropzone` передаёт принятые и отклонённые файлы в `onFiles`. Приложение загружает их в своё хранилище и передаёт прогресс, отмену и повтор в `UploadItem`. [Комбобокс в WAI-ARIA APG](https://www.w3.org/WAI/ARIA/apg/patterns/combobox/)
- **iOS и системная клавиатура.** Передай в `AdaptiveNavigation` параметры `search`, `selectionActive` и слот `selection`. На узком экране триггер поиска появляется в заголовке. В режиме выбора слот занимает место навбара. При наборе текста док скрывается, а открытый поиск остаётся доступен в верхней области. В гибридном приложении можно передать `keyboardVisible` явно. В вебе учитываются фокус и размер VisualViewport. [VisualViewport API](https://developer.chrome.com/blog/visual-viewport-api/)
- **Подсказки.** Тултип открывается по наведению и клавиатурному фокусу. Для интерактивной карточки используй `Popover`, закрываемый по Escape с возвратом фокуса. [Popover Radix](https://www.radix-ui.com/primitives/docs/components/popover) · [Tooltip Radix](https://www.radix-ui.com/primitives/docs/components/tooltip)
- **Скраббер.** Пройденный участок становится волной во время воспроизведения. Пауза, перемотка и системный Reduce Motion дают прямую линию. Приложение передаёт время, длительность, состояние playback и обработчики. Стрелки перемещают позицию на 5 секунд, PageUp/PageDown на 10% длительности с минимумом в 5 секунд, Home/End ведут в начало и конец.

Поведение навигации сверено с [TabBar из SFUI на ревизии fc7bfac](https://github.com/nactech/sfui/blob/fc7bfac/src/components/TabBar/TabBar.tsx).

## Окраска и материалы

```tsx
import {resolveOrbitTheme, OrbitProvider} from '@kiridey/orbit-ui';

const theme = resolveOrbitTheme({style: 'orbit', base: 'oled', colorMode: 'tinted', seed: '#98B893'});
<OrbitProvider style={theme.resolvedTokens}>{/* приложение */}</OrbitProvider>;
```

- Без `style` используется палитра Orbit D5. Передай `colorMode: 'accent'`, чтобы менять акценты, или `colorMode: 'tinted'`, чтобы добавить оттенок поверхностям. В профиле можно сохранить `seed`, режим и полученные `resolvedTokens`. `base: 'oled'` оставляет фон чёрным, `base: 'dark'` в режиме `tinted` слегка окрашивает его.
- Для выбранного пункта навигации служат `--orbit-tonal` и `--orbit-on-tonal`. Основное действие использует `--orbit-accent` и `--orbit-on-accent`. Цвета ошибки, предупреждения и успеха сохраняют собственные роли.
- Обычные поля и карточки используй на непрозрачных поверхностях. Стекло применяется на плавающей навигации и действиях поверх контента. `material="solid"` у `TabBar` выбирает сплошной вариант.
- При добавлении компонента возьми за основу ближайший примитив. Подхватывай типографику и цвета через `OrbitProvider` и `--orbit-*`, используй существующие состояния фокуса и отключения. Форма кнопки и активной вкладки допускает капсулу, а вложенные панели со скруглением подбираются по отступу от внешнего контура.

## Каталог и экран «Файлы»

В исходниках запусти `npm ci` и `npm run dev`. Путь `/` открывает пилотный экран, `/library.html` открывает интерактивный каталог. Пилот хранит изменения в браузере, скачивает демонстрационные файлы и имитирует воспроизведение. Каталог читает выбранные файлы локально для показа прогресса и ошибок. Фото в примере — [Unsplash](https://images.unsplash.com/photo-1601585340209-a72dc59bc083).

`npm run check` проверяет типы, `npm run test` запускает Chromium и WebKit, `npm run build` собирает пакет, а `npm run build:demo` собирает каталог и пилот в `demo-dist`.
